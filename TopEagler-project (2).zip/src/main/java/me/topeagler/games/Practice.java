package me.topeagler.games;

import me.topeagler.TopEagler;
import me.topeagler.managers.GameManager;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class Practice {
    private final TopEagler plugin;
    private final GameManager manager;
    public Practice(TopEagler plugin, GameManager manager) { this.plugin = plugin; this.manager = manager; }
    public void join(Player p) {
        p.getInventory().clear();
        p.setHealth(20.0); p.setFoodLevel(20);
        p.sendMessage(ChatColor.GREEN + "Practice PvP selected. Use this arena to spar; matchmaking/kit selection can be added next.");
    }
    public void leave(Player p) {}
    public void onDeath(Player p) { p.sendMessage(ChatColor.YELLOW + "Practice round ended."); }
}
