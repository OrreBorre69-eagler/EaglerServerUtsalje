package me.topeagler.games;

import me.topeagler.TopEagler;
import me.topeagler.managers.GameManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class HungerGames {
    private final TopEagler plugin;
    private final GameManager manager;
    private final Set<UUID> alive = new HashSet<UUID>();
    private BukkitTask countdown;
    public HungerGames(TopEagler plugin, GameManager manager) { this.plugin = plugin; this.manager = manager; }
    public void join(Player p) {
        alive.add(p.getUniqueId());
        p.getInventory().clear();
        p.setHealth(20.0); p.setFoodLevel(20);
        p.sendMessage(ChatColor.GOLD + "Hunger Games: gather loot and survive. The round starts when enough players join.");
        int min = plugin.getConfig().getInt("settings.hunger-games-min-players", 2);
        if (alive.size() >= min && countdown == null) startCountdown();
    }
    private void startCountdown() {
        final int[] seconds = {plugin.getConfig().getInt("settings.hunger-games-countdown-seconds", 15)};
        countdown = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            public void run() {
                if (alive.size() < plugin.getConfig().getInt("settings.hunger-games-min-players", 2)) {
                    broadcast(ChatColor.RED + "Not enough players; countdown cancelled.");
                    countdown.cancel(); countdown = null; return;
                }
                if (seconds[0] <= 0) {
                    broadcast(ChatColor.GREEN + "Hunger Games started! (Arena/loot/chest setup is yours to build next.)");
                    countdown.cancel(); countdown = null; return;
                }
                if (seconds[0] <= 5 || seconds[0] % 5 == 0) broadcast(ChatColor.YELLOW + "Starting in " + seconds[0] + "...");
                seconds[0]--;
            }
        }, 0L, 20L);
    }
    public void onDeath(Player p) {
        alive.remove(p.getUniqueId());
        Bukkit.getScheduler().runTaskLater(plugin, new Runnable() {
            public void run() {
                if (alive.size() <= 1) {
                    for (UUID id : alive) {
                        Player winner = Bukkit.getPlayer(id);
                        if (winner != null) winner.sendMessage(ChatColor.GOLD + "You won Hunger Games!");
                    }
                }
            }
        }, 2L);
    }
    public void leave(Player p) { alive.remove(p.getUniqueId()); }
    private void broadcast(String msg) {
        for (UUID id : alive) { Player p = Bukkit.getPlayer(id); if (p != null) p.sendMessage(msg); }
    }
    public void shutdown() { if (countdown != null) countdown.cancel(); }
}
