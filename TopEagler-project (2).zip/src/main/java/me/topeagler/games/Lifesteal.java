package me.topeagler.games;

import me.topeagler.TopEagler;
import me.topeagler.managers.GameManager;
import org.bukkit.ChatColor;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Lifesteal {
    private final TopEagler plugin;
    private final GameManager manager;
    private final Map<UUID, Integer> hearts = new HashMap<UUID, Integer>();
    public Lifesteal(TopEagler plugin, GameManager manager) { this.plugin = plugin; this.manager = manager; }
    public void join(Player p) {
        int start = plugin.getConfig().getInt("settings.lifesteal-starting-hearts", 10);
        hearts.put(p.getUniqueId(), start);
        apply(p, start);
        p.sendMessage(ChatColor.RED + "Lifesteal: eliminate opponents to gain a heart.");
    }
    public void leave(Player p) { hearts.remove(p.getUniqueId()); p.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(20.0); p.setHealth(Math.min(20.0, p.getHealth())); }
    public void onDeath(Player victim, Player killer) {
        int v = Math.max(1, hearts.containsKey(victim.getUniqueId()) ? hearts.get(victim.getUniqueId()) - 1 : 9);
        hearts.put(victim.getUniqueId(), v); apply(victim, v);
        if (killer != null && manager.mode(killer) != null && manager.mode(killer).equals("lifesteal")) {
            int k = hearts.containsKey(killer.getUniqueId()) ? hearts.get(killer.getUniqueId()) + 1 : 11;
            hearts.put(killer.getUniqueId(), Math.min(20, k)); apply(killer, Math.min(20, k));
            killer.sendMessage(ChatColor.GREEN + "You stole a heart!");
        }
    }
    private void apply(Player p, int amount) {
        double max = Math.max(2.0, Math.min(40.0, amount * 2.0));
        p.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(max);
        p.setHealth(Math.min(max, Math.max(1.0, p.getHealth())));
    }
}
