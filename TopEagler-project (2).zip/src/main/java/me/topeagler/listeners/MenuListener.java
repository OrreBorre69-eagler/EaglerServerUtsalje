package me.topeagler.listeners;

import me.topeagler.TopEagler;
import me.topeagler.managers.GameManager;
import me.topeagler.managers.MenuManager;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class MenuListener implements Listener {
    private final TopEagler plugin;
    private final GameManager games;
    public MenuListener(TopEagler plugin, GameManager games) { this.plugin = plugin; this.games = games; }
    @EventHandler public void onClick(InventoryClickEvent event) {
        if (event.getView() == null || !MenuManager.TITLE.equals(event.getView().getTitle())) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player) || event.getCurrentItem() == null || !event.getCurrentItem().hasItemMeta()) return;
        String name = ChatColor.stripColor(event.getCurrentItem().getItemMeta().getDisplayName());
        Player p = (Player) event.getWhoClicked();
        if ("Lifesteal".equals(name)) games.join(p, "lifesteal");
        else if ("Hunger Games".equals(name)) games.join(p, "hungergames");
        else if ("Practice PvP".equals(name)) games.join(p, "practice");
        else return;
        p.closeInventory();
    }
}
