package me.topeagler.listeners;

import me.topeagler.TopEagler;
import me.topeagler.managers.GameManager;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class PlayerListener implements Listener {
    private final TopEagler plugin;
    private final GameManager games;
    public PlayerListener(TopEagler plugin, GameManager games) { this.plugin = plugin; this.games = games; }

    @EventHandler public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        games.onDeath(victim, killer);
        if (games.mode(victim) != null) {
            event.setDeathMessage(ChatColor.GRAY + victim.getName() + " was eliminated.");
        }
    }
    @EventHandler public void onQuit(PlayerQuitEvent event) { games.leave(event.getPlayer()); }
    @EventHandler public void onRespawn(PlayerRespawnEvent event) {
        final Player p = event.getPlayer();
        if (games.lobby() != null) event.setRespawnLocation(games.lobby());
    }
}
