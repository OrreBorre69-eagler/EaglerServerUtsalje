package me.topeagler;

import me.topeagler.commands.GamesCommand;
import me.topeagler.commands.SetArenaCommand;
import me.topeagler.commands.SetLobbyCommand;
import me.topeagler.listeners.MenuListener;
import me.topeagler.listeners.PlayerListener;
import me.topeagler.managers.GameManager;
import me.topeagler.managers.MenuManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class TopEagler extends JavaPlugin {
    private GameManager gameManager;
    private MenuManager menuManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.gameManager = new GameManager(this);
        this.menuManager = new MenuManager(this);
        getCommand("games").setExecutor(new GamesCommand(menuManager));
        getCommand("setlobby").setExecutor(new SetLobbyCommand(this));
        getCommand("setarena").setExecutor(new SetArenaCommand(this));
        Bukkit.getPluginManager().registerEvents(new MenuListener(this, gameManager), this);
        Bukkit.getPluginManager().registerEvents(new PlayerListener(this, gameManager), this);
        getLogger().info("TopEagler enabled. Use /games to open the selector.");
    }

    @Override
    public void onDisable() {
        if (gameManager != null) gameManager.shutdown();
    }

    public GameManager getGameManager() { return gameManager; }
}
