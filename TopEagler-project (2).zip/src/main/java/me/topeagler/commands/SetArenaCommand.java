package me.topeagler.commands;

import me.topeagler.TopEagler;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class SetArenaCommand implements CommandExecutor {
    private final TopEagler plugin;
    public SetArenaCommand(TopEagler plugin) { this.plugin = plugin; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage("Players only."); return true; }
        if (!sender.hasPermission("topeagler.admin")) { sender.sendMessage(ChatColor.RED + "No permission."); return true; }
        if (args.length != 1) { sender.sendMessage(ChatColor.YELLOW + "Usage: /setarena <lifesteal|hungergames|practice>"); return true; }
        String mode = args[0].toLowerCase();
        if (!mode.equals("lifesteal") && !mode.equals("hungergames") && !mode.equals("practice")) {
            sender.sendMessage(ChatColor.RED + "Unknown mode."); return true;
        }
        plugin.getConfig().set("arenas." + mode, LocationUtil.serialize(((Player)sender).getLocation()));
        plugin.saveConfig();
        sender.sendMessage(ChatColor.GREEN + "Arena spawn saved for " + mode + ".");
        return true;
    }
}
