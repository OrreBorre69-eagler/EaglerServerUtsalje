package me.topeagler.commands;

import me.topeagler.TopEagler;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class SetLobbyCommand implements CommandExecutor {
    private final TopEagler plugin;
    public SetLobbyCommand(TopEagler plugin) { this.plugin = plugin; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage("Players only."); return true; }
        if (!sender.hasPermission("topeagler.admin")) { sender.sendMessage(ChatColor.RED + "No permission."); return true; }
        plugin.getConfig().set("lobby", LocationUtil.serialize(((Player) sender).getLocation()));
        plugin.saveConfig();
        sender.sendMessage(ChatColor.GREEN + "Lobby spawn saved.");
        return true;
    }
}
