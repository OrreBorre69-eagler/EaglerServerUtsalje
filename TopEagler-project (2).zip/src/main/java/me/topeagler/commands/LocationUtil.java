package me.topeagler.commands;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import java.util.HashMap;
import java.util.Map;

public final class LocationUtil {
    private LocationUtil() {}
    public static Map<String, Object> serialize(Location loc) {
        Map<String, Object> m = new HashMap<String, Object>();
        m.put("world", loc.getWorld().getName()); m.put("x", loc.getX()); m.put("y", loc.getY());
        m.put("z", loc.getZ()); m.put("yaw", loc.getYaw()); m.put("pitch", loc.getPitch());
        return m;
    }
    public static Location read(ConfigurationSection section) {
        if (section == null) return null;
        String worldName = section.getString("world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world, section.getDouble("x"), section.getDouble("y"), section.getDouble("z"),
                (float)section.getDouble("yaw"), (float)section.getDouble("pitch"));
    }
}
