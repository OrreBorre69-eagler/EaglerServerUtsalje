package me.topeagler.commands;

import me.topeagler.managers.MenuManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GamesCommand implements CommandExecutor {
    private final MenuManager menu;
    public GamesCommand(MenuManager menu) { this.menu = menu; }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage("Players only."); return true; }
        menu.open((Player) sender);
        return true;
    }
}
