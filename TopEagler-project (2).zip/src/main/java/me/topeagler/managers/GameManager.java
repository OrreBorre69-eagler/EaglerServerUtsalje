package me.topeagler.managers;

import me.topeagler.TopEagler;
import me.topeagler.commands.LocationUtil;
import me.topeagler.games.HungerGames;
import me.topeagler.games.Lifesteal;
import me.topeagler.games.Practice;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GameManager {
    private final TopEagler plugin;
    private final Map<UUID, String> modes = new HashMap<UUID, String>();
    private final Lifesteal lifesteal;
    private final HungerGames hungerGames;
    private final Practice practice;

    public GameManager(TopEagler plugin) {
        this.plugin = plugin;
        lifesteal = new Lifesteal(plugin, this);
        hungerGames = new HungerGames(plugin, this);
        practice = new Practice(plugin, this);
    }
    public void join(Player p, String mode) {
        leave(p);
        modes.put(p.getUniqueId(), mode);
        Location loc = arena(mode);
        if (loc == null) {
            modes.remove(p.getUniqueId());
            p.sendMessage(ChatColor.RED + "No spawn configured for " + mode + ". Ask an admin to run /setarena " + mode + ".");
            return;
        }
        p.teleport(loc);
        p.sendMessage(ChatColor.GREEN + "Joining " + mode + "!");
        if (mode.equals("lifesteal")) lifesteal.join(p);
        else if (mode.equals("hungergames")) hungerGames.join(p);
        else if (mode.equals("practice")) practice.join(p);
    }
    public void leave(Player p) {
        String mode = modes.remove(p.getUniqueId());
        if (mode == null) return;
        if (mode.equals("lifesteal")) lifesteal.leave(p);
        else if (mode.equals("hungergames")) hungerGames.leave(p);
        else if (mode.equals("practice")) practice.leave(p);
    }
    public String mode(Player p) { return modes.get(p.getUniqueId()); }
    public void onDeath(Player p, Player killer) {
        String mode = mode(p);
        if (mode == null) return;
        if (mode.equals("lifesteal")) lifesteal.onDeath(p, killer);
        else if (mode.equals("hungergames")) hungerGames.onDeath(p);
        else if (mode.equals("practice")) practice.onDeath(p);
    }
    public Location lobby() {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("lobby");
        return LocationUtil.read(section);
    }
    private Location arena(String mode) {
        return LocationUtil.read(plugin.getConfig().getConfigurationSection("arenas." + mode));
    }
    public void shutdown() { hungerGames.shutdown(); }
}
