package me.topeagler.managers;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.Arrays;

public class MenuManager {
    public static final String TITLE = ChatColor.DARK_AQUA + "TopEagler » Games";
    public MenuManager(org.bukkit.plugin.Plugin plugin) {}

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        inv.setItem(10, make(Material.DIAMOND_SWORD, ChatColor.RED + "Lifesteal", "PvP and steal hearts", "Click to join"));
        inv.setItem(13, make(Material.CHEST, ChatColor.GOLD + "Hunger Games", "Loot, survive, be last alive", "Click to join"));
        inv.setItem(16, make(Material.IRON_SWORD, ChatColor.GREEN + "Practice PvP", "Quick PvP practice", "Click to join"));
        ItemStack filler = make(Material.STAINED_GLASS_PANE, " ", " ");
        for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) inv.setItem(i, filler);
        player.openInventory(inv);
    }

    private ItemStack make(Material type, String name, String... lore) {
        ItemStack item = new ItemStack(type);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name); meta.setLore(Arrays.asList(lore));
        item.setItemMeta(meta);
        return item;
    }
}
