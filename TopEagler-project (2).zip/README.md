# TopEagler — Minecraft 1.12.2 starter plugin

This is a **starter project**, not a deployed public server. It includes a `/games` GUI, admin spawn commands, basic Lifesteal heart changes, a Hunger Games countdown, and a Practice PvP entry point.

## Requirements
- Java 8 JDK
- Maven 3.6+
- A server running Spigot/Paper 1.12.2 (or a compatible fork)
- For Eaglercraft browser players, a compatible Eaglercraft proxy/server setup. A Bukkit plugin alone does not make a server accessible to Eaglercraft clients.

## Build
Run in this folder:
```bash
mvn clean package
```
The plugin jar will be `target/TopEagler.jar`. Copy it to your server's `plugins/` folder and restart the server.

## First-time setup
1. Join as an operator.
2. Stand at the lobby spawn and run `/setlobby`.
3. Stand at the Lifesteal spawn and run `/setarena lifesteal`.
4. Repeat with `/setarena hungergames` and `/setarena practice` in the appropriate worlds/locations.
5. Use `/games`.

## Important limits
- Hunger Games currently has a player countdown and elimination tracking, but not a shrinking border, randomized loot, chests, spectating, or complete round reset.
- Practice currently gives a place to enter; it does not yet have 1v1 matchmaking or kit selection.
- Lifesteal's heart tracking is a basic prototype, not a production-ready persistent economy. It does not yet include heart-item crafting, ban/withdrawal rules, or saved heart data.
- Each mode currently uses configured spawn locations in the same server/world setup. `use-separate-servers` is reserved for a future proxy integration; it does not automatically connect servers.
- Test on a private test server before letting players join.

## Admin commands
- `/games` — open selector
- `/setlobby` — save lobby location
- `/setarena <lifesteal|hungergames|practice>` — save a mode spawn
